const a={cashPickup:"C",bankTransfer:"B",wallet:"W",all:function(){return[this.cashPickup,this.bankTransfer,this.wallet]}};export{a as P};
