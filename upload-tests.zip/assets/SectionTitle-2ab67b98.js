import{s as e,j as o,T as i}from"./index-cfcdf068.js";const s=e(t=>o(i,{color:"primary.main",...t}))(({theme:t})=>({fontSize:"14px",fontWeight:"600",letterSpacing:"0.5px"})),n=s;export{n as S};
