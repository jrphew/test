const n={grid:{rowSpacing:3,columnSpacing:2},button:{borderRadius:20}},o=n;export{o as D};
