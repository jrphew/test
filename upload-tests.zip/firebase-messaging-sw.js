// Scripts for firebase and firebase messaging
// eslint-disable-next-line no-undef
importScripts('https://www.gstatic.com/firebasejs/9.15.0/firebase-app-compat.js')
// eslint-disable-next-line no-undef
importScripts('https://www.gstatic.com/firebasejs/9.15.0/firebase-messaging-compat.js')

// Initialize the Firebase app in the service worker by passing the generated config
let firebaseConfig = {
  apiKey: 'AIzaSyAaC-r1fo17S1PaROxmSZZQTAjPTGbkJ1I',
  authDomain: 'isend-remit.firebaseapp.com',
  projectId: 'isend-remit',
  storageBucket: 'isend-remit.appspot.com',
  messagingSenderId: '878623851627',
  appId: '1:878623851627:web:d9bd59adc063211ba99d2e',
  measurementId: 'G-0GH3SFJWT4',
}

// eslint-disable-next-line no-undef
firebase.initializeApp(firebaseConfig)

// Retrieve firebase messaging
// eslint-disable-next-line no-undef
const messaging = firebase.messaging()

messaging.onBackgroundMessage(function (payload) {
  const notificationTitle = payload.notification.title
  const notificationOptions = {
    body: payload.notification.body,
    ...(payload.notification.image
      ? {
          image: payload.notification?.image,
        }
      : {}),
  }

  self.registration.showNotification(notificationTitle, notificationOptions)
})
