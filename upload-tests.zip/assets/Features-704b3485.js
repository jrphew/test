const e={banks:{allowedCountries:["USA"]}},s=e;export{s as F};
