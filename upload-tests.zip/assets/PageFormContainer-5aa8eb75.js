import{j as r,B as a}from"./index-cfcdf068.js";const t=({children:o})=>r(a,{sx:{maxWidth:"600px"},children:o}),s=t;export{s as P};
