const t={completed:"C",created:"I",expired:"E",notStarted:"N",processing:"P",rejected:"R"},e=t;export{e as K};
